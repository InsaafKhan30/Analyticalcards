sap.ui.define([
    "sap/ui/model/Filter"
], function (Filter) {
    "use strict";
    // controller for custom filter, navigation param, action(quick view and global filter), navigation target 
    // controller class name can be like app.ovp.ext.CustomFilter where app.ovp can be replaced with your application namespace
    return sap.ui.controller("S4.tm.csl.portcalloverview.ext.controller.OverViewPageExt", {

		/************************* Handler for custom navigation ************************************************
		 
		 * This function takes the standard navigation entry details (if present) for a particular card and context
		 * and return a new/modified custom navigation entry to the core. The core will then use the custom
		 * navigation entry to perform navigation
		 * @param sCardId  : Card id as defined in manifest for a card
		 * @param oContext : Context of line item that is clicked (empty for header click)
		 * @param oNavigationEntry : Custom navigation entry to be used for navigation
		 * @returns {object} : Properties are {type, semanticObject, action, url, label}
		 * @public
		 * sample code for referance
		    var oCustomNavigationEntry;
		    var oEntity = oContext && oContext.sPath && oContext.getProperty && oContext.getProperty(oContext.sPath);
		    if (sCardId === "card001" && oEntity && oEntity.PurchaseOrder === "4500003575") {
		        oCustomNavigationEntry = {};
		        oCustomNavigationEntry.type = "com.sap.vocabularies.UI.v1.DataFieldForIntentBasedNavigation";
		        oCustomNavigationEntry.semanticObject = "Action";
		        oCustomNavigationEntry.action = "toappnavsample";
		        oCustomNavigationEntry.url = ""; //Only required when type is DataFieldWithUrl
		        oCustomNavigationEntry.label = ""; //Optional
		    }
		    return oCustomNavigationEntry;
		 */

            doCustomNavigation: function (sCardId, oContext, oNavigationEntry) 
            {
                var oCustomNavigationEntry;
                var oEntity = oContext && oContext.sPath && oContext.getProperty && oContext.getProperty(oContext.sPath);
                if (sCardId === "CarrierCut" && oEntity ) {
                  oCustomNavigationEntry = {};
                  oCustomNavigationEntry.type = "com.sap.vocabularies.UI.v1.DataFieldForIntentBasedNavigation";
                  oCustomNavigationEntry.semanticObject = "UI_PORTCALLANALYSIS";
                  oCustomNavigationEntry.action = "display";
                  oCustomNavigationEntry.url = ""; //Only required when type is DataFieldWithUrl
                  oCustomNavigationEntry.label = ""; //Optional
                }
                return oCustomNavigationEntry;
            },        

        onCustomParams: function(sCustomParams) {
            if (sCustomParams === "CarrierCuts") {
                return this.CarrierCuts;
            } else if (sCustomParams === "param2") {
                return this.param2;
            }
        },
        // Adding the function details for Carrier Cut function
        CarrierCuts: function (oNavigateParams) {
            //Valid only for header navigation where oNavigateParams is am empty object
            if (Object.keys(oNavigateParams).length === 0) {
              var aCustomSelectionVariant = [];
              /*Adding a custom navigation parameter to ensure only products in stock are shown in the         target app*/
              var oCustomSelectionVariant = {
                  path: "Status",
                  operator: "EQ",
                  value1: "Cut",
                  value2: "null",
                  sign: "I",
              };
              var oResponsibleParty = {
                  path: "ResponsibleParty",
                  operator: "BT",
                  value1: "Carrier",
                  value2: "Customer",
                  sign: "I"
               };
              aCustomSelectionVariant.push(oCustomSelectionVariant);
              aCustomSelectionVariant.push(oResponsibleParty);
              return { aCustomSelectionVariant,
                ignoreEmptyString: true };
              /*You will need the following if you wish to ignore any select options to be ignored during navigation, with ignoreEmptyString as true, this will be removed from the Selection Variant. In this sample we will ignore the Country Code filter applied.
           */
              }
          }
        });
});