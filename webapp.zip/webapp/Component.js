sap.ui.define(["sap/ovp/app/Component"], function(AppComponent) {
    return AppComponent.extend("S4.tm.csl.portcalloverview.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
